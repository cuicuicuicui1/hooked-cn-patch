﻿# 图集分段改写：把补丁里那几十 KB 的改动写回 1GB 的 .resS（不改文件长度）
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$dir  = Join-Path $PSScriptRoot "payload_splice"
$manPath = Join-Path $dir "manifest.json"
if (-not (Test-Path $manPath)) { Write-Host "图集分段改写：无内容，跳过"; exit 0 }
$man = Get-Content $manPath -Raw -Encoding UTF8 | ConvertFrom-Json
$target = Join-Path $root $man.target
if (-not (Test-Path $target)) { Write-Host "找不到 $($man.target) —— 请把补丁文件夹放进游戏根目录。" -ForegroundColor Red; exit 1 }
function Sha256($p) { (Get-FileHash -Algorithm SHA256 -Path $p).Hash.ToLower() }
$now = Sha256 $target
if ($now -eq $man.sha256_after) { Write-Host "图集分段改写：已是目标状态，跳过" -ForegroundColor Green; exit 0 }
if ($now -ne $man.sha256_before) {
    Write-Host "警告：$($man.target) 与补丁记录的原始版本不一致（游戏版本可能不同）。" -ForegroundColor Yellow
    $a = Read-Host "仍然继续吗? (y/N)"
    if ($a -ne 'y') { Write-Host "已取消。" -ForegroundColor Yellow; exit 1 }
}
$fs = [System.IO.File]::Open($target, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    foreach ($op in $man.ops) {
        $bytes = [System.IO.File]::ReadAllBytes((Join-Path $dir $op.patch))
        [void]$fs.Seek($op.offset, [System.IO.SeekOrigin]::Begin)
        $fs.Write($bytes, 0, $bytes.Length)
    }
} finally { $fs.Close() }
if ((Sha256 $target) -ne $man.sha256_after) { Write-Host "图集改写后校验失败！请用卸载脚本还原。" -ForegroundColor Red; exit 1 }
Write-Host "图集分段改写完成（$($man.ops.Count) 段）" -ForegroundColor Green
