﻿# 汉化补丁安装脚本 —— 由 ZCode 生成,只做三件事:校验、备份、覆盖
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot          # 游戏根目录(补丁文件夹的上级)
$payload = Join-Path $PSScriptRoot "payload"
$manifest = Get-Content (Join-Path $PSScriptRoot "manifest.json") -Raw -Encoding UTF8 | ConvertFrom-Json
$backup = Join-Path $PSScriptRoot "备份原文件"

function Sha256($path) { (Get-FileHash -Algorithm SHA256 -Path $path).Hash.ToLower() }

Write-Host "游戏目录: $root" -ForegroundColor Cyan
if (-not (Test-Path (Join-Path $root $manifest.game_exe))) {
    Write-Host "找不到 $($manifest.game_exe) —— 请把补丁文件夹放到游戏根目录里再运行。" -ForegroundColor Red
    Read-Host "按回车退出"; exit 1
}

$mismatch = @()
foreach ($f in $manifest.files) {
    if ($f.check_only) {
        $dst = Join-Path $root $f.path
        if ((Test-Path $dst) -and $f.source_sha256 -and (Sha256 $dst) -ne $f.source_sha256) { $mismatch += $f.path }
        continue
    }
    $src = Join-Path $payload $f.path
    if (-not (Test-Path $src)) { Write-Host "补丁文件缺失: $($f.path)" -ForegroundColor Red; Read-Host "按回车退出"; exit 1 }
    $dst = Join-Path $root $f.path
    if ($f.source_sha256 -and (Test-Path $dst)) {
        $now = Sha256 $dst
        if ($now -ne $f.source_sha256) { $mismatch += $f.path }
    }
}
if ($mismatch.Count -gt 0) {
    Write-Host "以下文件与补丁记录的原始版本不一致(游戏版本可能不同):" -ForegroundColor Yellow
    $mismatch | ForEach-Object { Write-Host "   $_" -ForegroundColor Yellow }
    $ans = Read-Host "仍然继续吗? 原文件会先备份 (y/N)"
    if ($ans -ne "y" -and $ans -ne "Y") { exit 1 }
}

foreach ($f in $manifest.files) {
    if ($f.check_only) { continue }
    $src = Join-Path $payload $f.path
    $dst = Join-Path $root $f.path
    $dstDir = Split-Path -Parent $dst
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
    if (Test-Path $dst) {
        $bak = Join-Path $backup $f.path
        $bakDir = Split-Path -Parent $bak
        if (-not (Test-Path $bakDir)) { New-Item -ItemType Directory -Path $bakDir -Force | Out-Null }
        if (-not (Test-Path $bak)) { Copy-Item $dst $bak -Force }
    }
    Copy-Item $src $dst -Force
    $now = Sha256 $dst
    if ($now -ne $f.target_sha256) {
        Write-Host "写入后校验失败: $($f.path)" -ForegroundColor Red
        Write-Host "请用「卸载汉化.bat」还原,并把这条信息反馈给作者。" -ForegroundColor Red
        Read-Host "按回车退出"; exit 1
    }
    Write-Host "  OK  $($f.path)" -ForegroundColor Green
}
Write-Host ""
Write-Host "汉化完成! 直接启动游戏即可。原文件已备份在 备份原文件\ 里。" -ForegroundColor Green
Read-Host "按回车退出"

& (Join-Path $PSScriptRoot "splice_apply.ps1")
