﻿& (Join-Path $PSScriptRoot "splice_restore.ps1")
# 还原脚本:把备份的文件放回原位
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$backup = Join-Path $PSScriptRoot "备份原文件"
if (-not (Test-Path $backup)) { Write-Host "没有备份,无法还原。" -ForegroundColor Red; Read-Host "按回车退出"; exit 1 }
Get-ChildItem -Path $backup -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($backup.Length + 1)
    $dst = Join-Path $root $rel
    $dstDir = Split-Path -Parent $dst
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Path $dstDir -Force | Out-Null }
    Copy-Item $_.FullName $dst -Force
    Write-Host "  还原 $rel" -ForegroundColor Green
}
Remove-Item $backup -Recurse -Force
Write-Host "已还原到安装前的状态。" -ForegroundColor Green
Read-Host "按回车退出"
