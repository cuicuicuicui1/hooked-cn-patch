﻿# 还原 .resS 的分段改写（写回原始字节）
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$dir  = Join-Path $PSScriptRoot "payload_splice"
$manPath = Join-Path $dir "manifest.json"
if (-not (Test-Path $manPath)) { exit 0 }
$man = Get-Content $manPath -Raw -Encoding UTF8 | ConvertFrom-Json
$target = Join-Path $root $man.target
if (-not (Test-Path $target)) { Write-Host "找不到 $($man.target)，跳过分段还原" -ForegroundColor Yellow; exit 0 }
function Sha256($p) { (Get-FileHash -Algorithm SHA256 -Path $p).Hash.ToLower() }
if ((Sha256 $target) -eq $man.sha256_before) { Write-Host "图集分段：本来就是原始状态，跳过" -ForegroundColor Green; exit 0 }
$fs = [System.IO.File]::Open($target, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
try {
    foreach ($op in $man.ops) {
        $bytes = [System.IO.File]::ReadAllBytes((Join-Path $dir $op.orig))
        [void]$fs.Seek($op.offset, [System.IO.SeekOrigin]::Begin)
        $fs.Write($bytes, 0, $bytes.Length)
    }
} finally { $fs.Close() }
if ((Sha256 $target) -eq $man.sha256_before) { Write-Host "图集分段已还原为原始字节" -ForegroundColor Green } else { Write-Host "图集分段还原校验失败!" -ForegroundColor Red }
